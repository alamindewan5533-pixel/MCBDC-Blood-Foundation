package org.mcbdc.bloodfoundation

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { MaterialTheme { McbdcApp() } }
    }
}

private val auth get() = FirebaseAuth.getInstance()
private val db get() = FirebaseFirestore.getInstance()

@Composable
fun McbdcApp() {
    var page by remember { mutableStateOf("home") }
    var message by remember { mutableStateOf("") }
    var user by remember { mutableStateOf(auth.currentUser) }
    var isAdmin by remember { mutableStateOf(false) }
    var isSuper by remember { mutableStateOf(false) }

    LaunchedEffect(user?.uid) {
        if (user != null) {
            db.collection("admins").document(user!!.uid).get()
                .addOnSuccessListener { d ->
                    val active = d.getBoolean("active") == true
                    val role = d.getString("role")
                    isAdmin = active && (role == "admin" || role == "super_admin")
                    isSuper = active && role == "super_admin"
                }
        } else { isAdmin = false; isSuper = false }
    }

    Scaffold(topBar = {
        TopAppBar(title = { Text("MCBDC Blood Foundation") })
    }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Mirzapur College Blood Donors Club Committee", style = MaterialTheme.typography.bodySmall)
            when (page) {
                "register" -> RegisterScreen(
                    onDone = { message = it; page = "home" },
                    onBack = { page = "home" }
                )
                "login" -> LoginScreen(
                    onDone = { ok, msg -> message = msg; user = auth.currentUser; page = if (ok) "home" else "login" },
                    onBack = { page = "home" }
                )
                "members" -> if (isAdmin) AdminMembersScreen(onBack = { page = "home" }) else Text("এই অংশ শুধু অনুমোদিত Admin দেখতে পারবেন।")
                else -> {
                    Text("সবার জন্য সদস্য প্রোফাইল তৈরি", style = MaterialTheme.typography.titleLarge)
                    Text("সদস্যদের ব্যক্তিগত তথ্য শুধুমাত্র অনুমোদিত Admin দেখতে পারবেন।")
                    Button(onClick = { page = "register" }, modifier = Modifier.fillMaxWidth()) { Text("সদস্য নিবন্ধন") }
                    if (user == null) {
                        OutlinedButton(onClick = { page = "login" }, modifier = Modifier.fillMaxWidth()) { Text("Admin Login") }
                    } else {
                        Text("লগইন করা হয়েছে: ${user?.email ?: "Account"}")
                        if (isAdmin) Button(onClick = { page = "members" }, modifier = Modifier.fillMaxWidth()) { Text("Admin Dashboard") }
                        if (isSuper) Text("Super Admin access সক্রিয়")
                        OutlinedButton(onClick = { auth.signOut(); user = null; message = "Logout হয়েছে" }, modifier = Modifier.fillMaxWidth()) { Text("Logout") }
                    }
                    if (message.isNotBlank()) Text(message)
                    Text("নোট: ১৮ বছরের কম বয়সীরা স্বেচ্ছাসেবক/সদস্য হিসেবে নিবন্ধন করতে পারবে; রক্তদাতা হিসেবে নয়।")
                }
            }
        }
    }
}

@Composable
fun RegisterScreen(onDone: (String) -> Unit, onBack: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var blood by remember { mutableStateOf("নির্বাচন করুন") }
    var district by remember { mutableStateOf("টাঙ্গাইল") }
    var upazila by remember { mutableStateOf("মির্জাপুর") }
    var village by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var extra by remember { mutableStateOf("") }
    var saveState by remember { mutableStateOf("তথ্য পূরণ শুরু করুন — প্রয়োজনীয় তথ্য হলেই স্বয়ংক্রিয়ভাবে সংরক্ষণ হবে।") }
    var currentUid by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current
    var profileSaved by remember { mutableStateOf(false) }

    // Auto-save: no Submit button. Once the required fields are present,
    // each subsequent edit is saved automatically after a short pause.
    LaunchedEffect(name, phone, blood, district, upazila, village, dob, extra) {
        if (name.isBlank() || phone.isBlank() || village.isBlank() || blood == "নির্বাচন করুন") {
            saveState = "নাম, মোবাইল, রক্তের গ্রুপ ও গ্রাম পূরণ করলে প্রোফাইল নিজে থেকেই সংরক্ষিত হবে।"
            return@LaunchedEffect
        }
        delay(700)
        saveState = "স্বয়ংক্রিয়ভাবে সংরক্ষণ হচ্ছে..."
        val saveProfile: (String) -> Unit = { uid ->
            val data = hashMapOf(
                "uid" to uid, "name" to name.trim(), "phone" to phone.trim(),
                "bloodGroup" to blood, "district" to district.trim(),
                "upazila" to upazila.trim(), "village" to village.trim(),
                "dateOfBirth" to dob.trim(), "extra" to extra.trim(),
                "memberType" to "donor_candidate", "status" to "pending",
                "createdAt" to com.google.firebase.Timestamp.now(),
                "updatedAt" to com.google.firebase.Timestamp.now()
            )
            db.collection("members").document(uid).set(data)
                .addOnSuccessListener { profileSaved = true; saveState = "প্রোফাইল স্বয়ংক্রিয়ভাবে সংরক্ষিত হয়েছে।" }
                .addOnFailureListener { saveState = "সংরক্ষণ হয়নি: ${it.localizedMessage}" }
        }
        val existing = currentUid
        if (existing != null) {
            saveProfile(existing)
        } else {
            auth.signInAnonymously()
                .addOnSuccessListener { result ->
                    val uid = result.user?.uid
                    if (uid != null) {
                        currentUid = uid
                        saveProfile(uid)
                    } else saveState = "প্রোফাইল সংরক্ষণ করা যায়নি।"
                }
                .addOnFailureListener { saveState = "সংরক্ষণ শুরু করা যায়নি: ${it.localizedMessage}" }
        }
    }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("নিজের Donor Profile তৈরি করুন", style = MaterialTheme.typography.titleLarge) }
        item { Text("কোনো Submit বাটন নেই। প্রয়োজনীয় তথ্য পূরণ করলেই প্রোফাইল স্বয়ংক্রিয়ভাবে সংরক্ষিত হবে এবং Admin-এর তালিকায় যুক্ত হবে।") }
        item { OutlinedTextField(name, { name = it }, label = { Text("পূর্ণ নাম *") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(phone, { phone = it }, label = { Text("মোবাইল নম্বর *") }, modifier = Modifier.fillMaxWidth()) }
        item {
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                OutlinedTextField(blood, {}, readOnly = true, label = { Text("রক্তের গ্রুপ *") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    listOf("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-", "জানা নেই").forEach { v ->
                        DropdownMenuItem(text = { Text(v) }, onClick = { blood = v; expanded = false })
                    }
                }
            }
        }
        item { OutlinedTextField(district, { district = it }, label = { Text("জেলা") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(upazila, { upazila = it }, label = { Text("উপজেলা") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(village, { village = it }, label = { Text("গ্রাম/এলাকা *") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(dob, { dob = it }, label = { Text("জন্মতারিখ (DD-MM-YYYY)") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(extra, { extra = it }, label = { Text("অতিরিক্ত তথ্য (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth()) }
        item { Text("রক্তদাতা তালিকায় অন্তর্ভুক্তির আগে বয়স ১৮+ এবং রক্তের গ্রুপ যাচাই করতে হবে। ১৮ বছরের কম বয়সীরা স্বেচ্ছাসেবক/সদস্য হিসেবে থাকতে পারবে, donor হিসেবে নয়।") }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(saveState, style = MaterialTheme.typography.bodyMedium)
                    if (profileSaved) {
                        Divider()
                        Text("আমার Profile Card", style = MaterialTheme.typography.titleMedium)
                        Text("MCBDC Blood Foundation")
                        Text("নাম: $name")
                        Text("রক্তের গ্রুপ: $blood")
                        Text("এলাকা: $village, $upazila, $district")
                        Text("যোগাযোগ: $phone")
                        OutlinedButton(onClick = {
                            val card = "MCBDC Blood Foundation\\nনাম: $name\\nরক্তের গ্রুপ: $blood\\nএলাকা: $village, $upazila, $district\\nযোগাযোগ: $phone"
                            clipboard.setText(AnnotatedString(card))
                        }, modifier = Modifier.fillMaxWidth()) { Text("Profile Card Copy করুন") }
                    }
                }
            }
        }
        item { TextButton(onClick = onBack) { Text("ফিরে যান") } }
    }
}

@Composable
fun LoginScreen(onDone: (Boolean, String) -> Unit, onBack: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Admin Login", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(password, { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            auth.signInWithEmailAndPassword(email.trim(), password)
                .addOnSuccessListener { onDone(true, "Login সফল হয়েছে।") }
                .addOnFailureListener { onDone(false, "Login ব্যর্থ: ${it.localizedMessage}") }
        }, modifier = Modifier.fillMaxWidth()) { Text("Login") }
        TextButton(onClick = onBack) { Text("ফিরে যান") }
    }
}

@Composable
fun AdminMembersScreen(onBack: () -> Unit) {
    var members by remember { mutableStateOf(listOf<Map<String, Any>>()) }
    var donations by remember { mutableStateOf(listOf<Map<String, Any>>()) }
    var query by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("তথ্য লোড হচ্ছে...") }
    var selectedUid by remember { mutableStateOf("") }
    var selectedName by remember { mutableStateOf("") }
    var donationDate by remember { mutableStateOf("") }
    var donationPlace by remember { mutableStateOf("") }
    var donationNote by remember { mutableStateOf("") }
    var reportMonth by remember { mutableStateOf("") }

    fun refreshData() {
        db.collection("members").get()
            .addOnSuccessListener { snap ->
                members = snap.documents.mapNotNull { it.data }
                status = "${members.size}টি প্রোফাইল পাওয়া গেছে"
            }
            .addOnFailureListener { status = "সদস্য তালিকা লোড হয়নি: ${it.localizedMessage}" }
        db.collection("donations").get()
            .addOnSuccessListener { snap -> donations = snap.documents.mapNotNull { it.data } }
    }

    LaunchedEffect(Unit) { refreshData() }

    val monthTotals = donations
        .filter { reportMonth.isBlank() || it["date"]?.toString()?.startsWith(reportMonth) == true }
        .groupBy { (it["date"]?.toString() ?: "তারিখ নেই").take(7) }
        .mapValues { it.value.size }
        .toSortedMap(compareByDescending { it })

    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxSize()) {
        Text("Admin Dashboard", style = MaterialTheme.typography.titleLarge)
        Text(status)
        OutlinedTextField(query, { query = it }, label = { Text("নাম/রক্তের গ্রুপ দিয়ে খুঁজুন") }, modifier = Modifier.fillMaxWidth())
        Text("Donor / Member Profile List", style = MaterialTheme.typography.titleMedium)
        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(members.filter {
                val q = query.trim().lowercase()
                q.isEmpty() || (it["name"]?.toString()?.lowercase()?.contains(q) == true) ||
                    (it["bloodGroup"]?.toString()?.lowercase()?.contains(q) == true)
            }) { m ->
                val uid = m["uid"]?.toString() ?: ""
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(m["name"]?.toString() ?: "নাম নেই", style = MaterialTheme.typography.titleMedium)
                        Text("Blood: ${m["bloodGroup"] ?: "N/A"} | Phone: ${m["phone"] ?: "N/A"}")
                        Text("ঠিকানা: ${m["village"] ?: ""}, ${m["upazila"] ?: ""}, ${m["district"] ?: ""}")
                        Text("ধরন: ${m["profileType"] ?: "সাধারণ প্রোফাইল"} | Status: ${m["status"] ?: "pending"}")
                        Button(onClick = {
                            selectedUid = uid
                            selectedName = m["name"]?.toString() ?: ""
                        }) { Text("এই ব্যক্তির Donation Entry") }
                    }
                }
            }
        }

        if (selectedUid.isNotBlank()) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("$selectedName — Donation Entry", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(donationDate, { donationDate = it }, label = { Text("তারিখ (YYYY-MM-DD)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(donationPlace, { donationPlace = it }, label = { Text("কোথায় রক্তদান হয়েছে") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(donationNote, { donationNote = it }, label = { Text("অতিরিক্ত তথ্য (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        if (donationDate.matches(Regex("\\\\d{4}-\\\\d{2}-\\\\d{2}")) && donationPlace.isNotBlank()) {
                            val entry = hashMapOf(
                                "memberUid" to selectedUid, "memberName" to selectedName,
                                "date" to donationDate, "place" to donationPlace.trim(),
                                "note" to donationNote.trim(), "createdAt" to com.google.firebase.Timestamp.now(),
                                "createdBy" to (auth.currentUser?.uid ?: "")
                            )
                            db.collection("donations").add(entry)
                                .addOnSuccessListener {
                                    donationDate = ""; donationPlace = ""; donationNote = ""
                                    selectedUid = ""; selectedName = ""
                                    refreshData()
                                }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Donation Record Save") }
                    TextButton(onClick = { selectedUid = ""; selectedName = "" }) { Text("বাতিল") }
                }
            }
        }

        Divider()
        Text("Monthly Donation Report", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(reportMonth, { reportMonth = it }, label = { Text("মাস লিখুন (YYYY-MM), খালি রাখলে সব মাস") }, modifier = Modifier.fillMaxWidth())
        Text("মোট Donation: ${donations.count { reportMonth.isBlank() || it["date"]?.toString()?.startsWith(reportMonth) == true }}")
        monthTotals.forEach { (month, count) -> Text("$month : $count বার") }
        TextButton(onClick = onBack) { Text("ফিরে যান") }
    }
}

