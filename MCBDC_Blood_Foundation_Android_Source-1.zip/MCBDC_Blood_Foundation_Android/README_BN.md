# MCBDC Blood Foundation — Android source project

এটি Android Studio-তে খোলার জন্য Kotlin + Jetpack Compose + Firebase starter project।

## গুরুত্বপূর্ণ
- এটি এখনো installable APK নয়; এই পরিবেশে Android SDK/Gradle build tools নেই।
- Firebase project configuration ছাড়া online login/database চলবে না।
- বাস্তব সদস্যের ফোন/ঠিকানা যোগ করার আগে Firebase security rules পরীক্ষা ও deploy করতে হবে।
- Super Admin প্রথমে Firebase Console থেকে Auth user তৈরি করে Firestore `admins/{uid}` document-এ `role: "super_admin"` এবং `active: true` বসাবেন।
- সাধারণ Admin-এর document-এ `role: "admin"` ও `active: true` থাকবে। Admin যোগ/বাদ দেওয়ার কাজ নিরাপদ server-side Cloud Function দিয়ে করতে হবে; client app-এ admin privilege তৈরি করা যাবে না।
- সদস্যদের রেকর্ড private; public user অন্য সদস্যের তথ্য পড়তে পারবে না।
- ১৮ বছরের কম বয়সী কাউকে রক্তদাতা হিসেবে তালিকাভুক্ত করবেন না। সদস্য/স্বেচ্ছাসেবক হিসেবে নিবন্ধন করা যাবে। রক্তের গ্রুপ যাচাই হাসপাতাল/ল্যাবের মাধ্যমে করতে হবে।

## চালানোর ধাপ
1. Android Studio-তে এই project folder খুলুন।
2. Firebase Console-এ Android app তৈরি করুন। Package name: `org.mcbdc.bloodfoundation`
3. `google-services.json` ডাউনলোড করে `app/` folder-এ রাখুন।
4. Firebase Authentication-এ **Anonymous** sign-in চালু করুন (সাধারণ সদস্যদের Email/Password লাগবে না)। Admin login-এর জন্য Email/Password provider-ও চালু রাখুন।
5. Firestore Database তৈরি করে `firestore.rules` deploy করুন।
6. Android Studio-তে Gradle Sync করে Run চাপুন।
7. APK: Build > Build Bundle(s) / APK(s) > Build APK(s)।

## প্রথম Super Admin
Firebase Authentication থেকে Super Admin user তৈরি করুন। তার UID কপি করে Firestore-এ `admins/{UID}` document তৈরি করুন:
```json
{ "role": "super_admin", "active": true }
```
কখনোই Super Admin password অ্যাপে hardcode করবেন না বা কারও সঙ্গে শেয়ার করবেন না।

এই starter-এ যে কেউ অ্যাপ খুলে Email/Password ছাড়াই member profile জমা দিতে পারবে (Firebase Anonymous Authentication ব্যবহার করে)। জমা দেওয়া প্রোফাইল pending থাকবে; অনুমোদিত Admin-রা private member list দেখতে পারবেন। Production launch-এর আগে Cloud Functions দিয়ে admin management, audit logs, rate limiting, consent/retention policy এবং full security review যোগ করুন।

## Public profile submission
- Home screen থেকে “সদস্য নিবন্ধন” চাপলে যে কেউ profile form পূরণ করতে পারবে।
- সাধারণ সদস্যের Email/Password account দরকার নেই; app Firebase Anonymous Authentication দিয়ে নিরাপদ UID তৈরি করে।
- Firebase Console > Authentication > Sign-in method থেকে Anonymous enable করুন।
- Public user অন্য সদস্যের profile দেখতে পারবে না; Firestore rules-এ member read শুধু নিজের UID অথবা active Admin-এর জন্য।
- Anonymous profile একই app installation/user session-এর UID-র সঙ্গে যুক্ত। App data মুছে গেলে বা নতুন device হলে আগের profile-এর সঙ্গে স্বয়ংক্রিয়ভাবে যুক্ত নাও হতে পারে।


## Auto-save profile interface (no Submit button)
- Public profile form-এ Submit button রাখা হয়নি।
- নাম, ফোন, রক্তের গ্রুপ ও গ্রাম পূরণ হলে প্রোফাইল নিজে থেকেই সংরক্ষণ শুরু করে।
- এরপর যেকোনো field বদলালে অল্প বিরতির পর পরিবর্তনগুলো আবার auto-save হয়।
- Admin Dashboard-এর private members list-এ রেকর্ড পাওয়া যায়।
- নতুন রেকর্ড `pending` থাকে; Admin যাচাই না করা পর্যন্ত confirmed donor হিসেবে গণ্য নয়।
- Donor list-এ নেওয়ার আগে বয়স ১৮+ এবং blood group যাচাই করতে হবে।


## Profile Card ও Donation History
- Profile auto-save হওয়ার পর ব্যবহারকারী নিজের Profile Card দেখতে এবং text হিসেবে Copy করতে পারবেন।
- Admin Dashboard থেকে নির্দিষ্ট প্রোফাইলের জন্য Donation Entry যোগ করা যাবে।
- প্রতিটি entry-তে তারিখ (YYYY-MM-DD), কোথায় donation হয়েছে এবং optional note থাকবে।
- Monthly Donation Report-এ মাস (YYYY-MM) দিয়ে filter করে মোট donation count দেখা যাবে।
- Donation records কেবল active Admin/Super Admin পড়তে ও লিখতে পারবেন।
- বাস্তব রেকর্ডে ভুল এড়াতে Admin-কে দাতার পরিচয় ও donation date/place যাচাই করে entry দিতে হবে।


## দুইটি আলাদা Profile Interface
1. **সাধারণ ব্যক্তি হিসেবে Profile** — সবার জন্য উন্মুক্ত; কলেজের তথ্য বা Proof লাগবে না।
2. **কলেজ সদস্য হিসেবে Profile** — শ্রেণি/বর্ষ, কলেজ রোল এবং কলেজ ID Card/সদস্য Proof-এর ছবি বাধ্যতামূলক। Proof আপলোড হওয়ার পর Auto-save সম্পূর্ণ হবে।

Firebase Storage চালু করে `storage.rules` deploy করুন। Storage upload-এর জন্য Firebase Storage billing/plan availability আপনার Firebase project-এ যাচাই করুন। Proof ছবি ব্যক্তিগত তথ্য; Admin access ও retention policy নিশ্চিত না করে বাস্তব সদস্যদের ছবি সংগ্রহ করবেন না।
